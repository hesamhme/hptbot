fake_db = {}
# def generate_fake_profiles(num_profiles):
#     for i in range(num_profiles):
#         username = f"user_{i}"
#         fake_db[username] = {
#             "followers_count": random.randint(500, 5000),
#             "target": None
#         }
#     return fake_db
